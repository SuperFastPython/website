# SuperFastPython.com
# initialize a numpy array in parallel with threads
from concurrent.futures
import time
import numpy

# fill a portion of a larger array with a value
def fill_subarray(coords, data, value):
    # unpack array indexes
    i1, i2, i3, i4 = coords
    # populate subarray
    data[i1:i2,i3:i4].fill(value)

# record the start time
time_start = time.perf_counter()
# create an empty array
n = 50000
data = numpy.empty((n,n))
# create the thread pool
with concurrent.futures.ThreadPoolExecutor(4) as exe:
    # split each dimension (divisor of matrix dimension)
    split = round(n/2)
    # issue tasks
    for x in range(0, n, split):
        for y in range(0, n, split):
            # determine matrix coordinates
            coords = (x, x+split, y, y+split)
            # issue task
            _ = exe.submit(fill_subarray, coords, data, 1)
# calculate the duration
time_duration = time.perf_counter() - time_start
# report the duration
print(f'Took {time_duration:.3f} seconds')

