# SuperFastPython.com
# initialize a numpy array slowly
import time
import numpy
# record the start time
time_start = time.perf_counter()
# create a new matrix and fill with 1
data = numpy.ones((50000,50000))
# calculate and report duration
time_duration = time.perf_counter() - time_start
# report progress
print(f'Took {time_duration:.3f} seconds')
