# SuperFastPython.com
# example of benchmarking a list of numbers with timeit.timeit()
import timeit
# benchmark the i*i method
time_method1 = timeit.timeit('[i*i for i in range(1000)]', number=100000)
# report the duration
print(f'i*i: {time_method1} seconds')
# benchmark the i**2 method
time_method2 = timeit.timeit('[i**2 for i in range(1000)]', number=100000)
# report the duration
print(f'i**2: {time_method2} seconds')