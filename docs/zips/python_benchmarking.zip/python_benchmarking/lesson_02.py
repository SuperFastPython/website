# SuperFastPython.com
# example of benchmarking a statement with time.perf_counter()
import time
# record start time
time_start = time.perf_counter()
# execute the statement
data = [i*i for i in range(100000000)]
# record end time
time_end = time.perf_counter()
# calculate the duration
time_duration = time_end - time_start
# report the duration
print(f'Took {time_duration} seconds')
