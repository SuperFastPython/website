# SuperFastPython.com
# write to a file from multiple threads using a shared lock
import time
import random
import threading
import concurrent.futures

# task that blocks for a moment and write to a file
def task(name, lock, file_handle):
    # block for a moment
    value = random.random()
    time.sleep(value)
    # obtain the lock
    with lock:
        # write to a file
        file_handle.write(f'Task {name} blocked for {value} of a second.\n')
 
# write to a file from multiple threads
if __name__ == '__main__':
    # open a file
    with open('results.txt', 'a', encoding='utf-8') as handle:
        # create a lock to protect the file
        lock = threading.Lock()
        # create the thread pool
        with concurrent.futures.ThreadPoolExecutor(1000) as exe:
            # dispatch all tasks
            _ = [exe.submit(task, i, lock, handle) for i in range(10000)]
    # wait for all tasks to complete
    print('Done.')
