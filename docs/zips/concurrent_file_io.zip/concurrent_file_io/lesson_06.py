# SuperFastPython.com
# load many files concurrently with processes and threads in batch
import os
import os.path
import concurrent.futures
import time

# load a file and return the contents
def load_file(filepath):
    # open the file
    with open(filepath, 'r') as handle:
        # return the contents
        handle.read()

# return the contents of many files
def load_files(filepaths):
    # create a thread pool
    with concurrent.futures.ThreadPoolExecutor(len(filepaths)) as exe:
        # load files
        futures = [exe.submit(load_file, name) for name in filepaths]
        # collect data
        data_list = [future.result() for future in futures]
        # return data and file paths
        return (data_list, filepaths)

# load all files in a directory into memory
if __name__ == '__main__':
    # record the start time
    time_start = time.perf_counter()
    # define the pat to load fils
    path = 'tmp'
    # prepare all of the paths
    paths = [os.path.join(path, filepath) for filepath in os.listdir(path)]
    # determine chunksize
    n_workers = 8
    chunksize = round(len(paths) / n_workers)
    # create the process pool
    with concurrent.futures.ProcessPoolExecutor(n_workers) as exe:
        futures = list()
        # split the load operations into chunks
        for i in range(0, len(paths), chunksize):
            # select a chunk of filenames
            filepaths = paths[i:(i + chunksize)]
            # submit the task
            future = exe.submit(load_files, filepaths)
            futures.append(future)
        # process all results
        for future in concurrent.futures.as_completed(futures):
            # open the file and load the data
            _, filepaths = future.result()
            for filepath in filepaths:
                # report progress
                print(f'.loaded {filepath}')
    # calculate the duration
    time_duration = time.perf_counter() - time_start
    # report the duration
    print(f'Took {time_duration} seconds')
