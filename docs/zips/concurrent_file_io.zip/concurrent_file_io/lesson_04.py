# SuperFastPython.com
# save many data files concurrently with a process pool
import os
import os.path
import concurrent.futures
import time
 
# save data to a file
def save_file(filepath, data):
    # open the file
    with open(filepath, 'w') as handle:
        # save the data
        handle.write(data)
 
# generate a csv file with v=10 values per line and l=10k lines
def generate_file(identifier, n_values=10, n_lines=10000):
    # generate many lines of data
    data = list()
    for i in range(n_lines):
        # generate a list of numeric values as strings
        line = [str(identifier+i+j) for j in range(n_values)]
        # convert list to string with values separated by commas
        data.append(','.join(line))
    # convert list of lines to a string separated by new lines
    return '\n'.join(data)
 
# generate and save a file
def generate_and_save(path, identifier):
    # generate data
    data = generate_file(identifier)
    # create a unique filename
    filepath = os.path.join(path, f'data-{identifier:04d}.csv')
    # save data file to disk
    save_file(filepath, data)
    # report progress
    print(f'.saved {filepath}', flush=True)
 
# save many data files in a directory
if __name__ == '__main__':
    # record the start time
    time_start = time.perf_counter()
    # define the local dir to save files
    path = 'tmp'
    # define the number of files to save
    n_files = 10000
    # create a local directory to save files
    os.makedirs(path, exist_ok=True)
    # create the process pool
    with concurrent.futures.ProcessPoolExecutor(8) as exe:
        # submit tasks to generate files
        _ = [exe.submit(generate_and_save, path, i) for i in range(n_files)]
    # calculate the duration
    time_duration = time.perf_counter() - time_start
    # report the duration
    print(f'Took {time_duration} seconds')
