# SuperFastPython.com
# copy files from one directory to another concurrently with threads
import os
import os.path
import shutil
import concurrent.futures
import time

# copy a file from source to destination
def copy_file(src_path, dest_dir):
    # copy source file to dest file
    dest_path = shutil.copy(src_path, dest_dir)
    # report progress
    print(f'.copied {src_path} to {dest_path}')
 
# copy files from src to dest
if __name__ == '__main__':
    # record the start time
    time_start = time.perf_counter()
    # define the source and destimation dirs
    src = 'tmp'
    dest = 'tmp2'
    # create the destination directory if needed
    os.makedirs(dest, exist_ok=True)
    # create full paths for all files we wish to copy
    files = [os.path.join(src,name) for name in os.listdir(src)]
    # create the thread pool
    with concurrent.futures.ThreadPoolExecutor(100) as exe:
        # submit all copy tasks
        _ = [exe.submit(copy_file, path, dest) for path in files]
    print('Done')
     # calculate the duration
    time_duration = time.perf_counter() - time_start
    # report the duration
    print(f'Took {time_duration} seconds')