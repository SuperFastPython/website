# SuperFastPython.com
# example of trying to cancel a done task via its future
from time import sleep
from concurrent.futures import ProcessPoolExecutor
from concurrent.futures import wait

# mock task that will sleep for a moment
def work(sleep_time):
    sleep(sleep_time)

# entry point
def main():
    # create a process pool
    with ProcessPoolExecutor(1) as executor:
        # start a long running task
        future = executor.submit(work, 2)
        running = future.running()
        # wait for the task to finish
        wait([future])
        # check the status
        running = future.running()
        cancelled = future.cancelled()
        done = future.done()
        print(f'Task running={running}, cancelled={cancelled}, done={done}')
        # try to cancel the task
        was_cancelled = future.cancel()
        print(f'Task was cancelled: {was_cancelled}')
        # check if it was cancelled
        running = future.running()
        cancelled = future.cancelled()
        done = future.done()
        print(f'Task running={running}, cancelled={cancelled}, done={done}')

if __name__ == '__main__':
    main()
